THE WIND REMEMBERS
Windows x86_64 REV challenge

Extract this archive and run game.exe from this directory.
Keep game.exe, game.pck, and libtrial.dll together.

Controls:
    WASD       Move
    Mouse      Look
    F          Toggle torch
    I          Inventory
    E          Interact / inspect
    J          Read recovered fragments
    Escape     Release or capture mouse; close menus

The game uses Godot 4.7.2's Compatibility renderer.
Godot Engine is distributed under the MIT license in LICENSE-GODOT.txt.
The native library uses LLVM-MinGW under the terms in
LICENSE-NATIVE-TOOLCHAIN.txt. All game geometry, visual effects, textures,
and audio are original procedural work. No Sketchfab, Minecraft, or Zelda
asset is included.
